export default ['packages/*', 'apps/*'];
