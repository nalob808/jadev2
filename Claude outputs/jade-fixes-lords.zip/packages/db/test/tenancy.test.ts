import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { sql } from 'drizzle-orm';
import { createDatabase, type Database } from '../src/client.js';
import { withWorkspace } from '../src/tenancy.js';
import { subjects } from '../src/schema.js';
import { EXPECTED_MIGRATIONS, LATEST_MIGRATION, schemaStatus } from '../src/schemaStatus.js';
import {
  bootstrapUser,
  createRelationship,
  createWatch,
  deleteWatch,
  listUpcomingHits,
  listWatches,
  recordWatchHits,
  createSubjectWithBirthEvent,
  deleteRelationship,
  exportSubject,
  getSubject,
  hardDeleteSubject,
  listRelationships,
  listSubjects,
  orderPair,
  searchPlaces,
  softDeleteSubject,
} from '../src/queries.js';

/**
 * These tests need a real Postgres. Without TEST_DATABASE_URL they skip, so
 * `pnpm test` stays green on a laptop with no database — but CI and anyone
 * with a local Postgres gets the real thing, including proof that row-level
 * security actually isolates one practice from another.
 *
 *   createdb jade_test
 *   TEST_DATABASE_URL=postgresql://... pnpm --filter @jade/db test
 *
 * The connecting role must NOT be a superuser: superusers bypass RLS
 * unconditionally, and a test that passes because the check was skipped is
 * worse than no test.
 */
const url = process.env.TEST_DATABASE_URL;
const describeWithDb = url ? describe : describe.skip;

/**
 * Guard: these tests TRUNCATE every table. Pointing TEST_DATABASE_URL at a
 * database holding real charts would destroy them, and the variable is one
 * careless copy-paste away from a production connection string.
 *
 * So: the URL must look like a test database, or you must say out loud that
 * you meant it.
 */
function assertSafeToTruncate(connectionString: string): void {
  const looksLikeTest = /test|localhost|127\.0\.0\.1|_dev\b/i.test(connectionString);
  if (!looksLikeTest && process.env.ALLOW_DESTRUCTIVE_TESTS !== '1') {
    throw new Error(
      'TEST_DATABASE_URL does not look like a test database, and these tests truncate every table. ' +
        'Point it at a scratch database, or set ALLOW_DESTRUCTIVE_TESTS=1 if you are certain.',
    );
  }
}

let database: Database;
let alice: { workspaceId: string; userId: string };
let bob: { workspaceId: string; userId: string };

const birthEventFixture = {
  label: 'birth',
  localDatetime: '2001-11-07T10:32:00',
  utcDatetime: new Date(Date.UTC(2001, 10, 7, 15, 32)),
  utcOffsetMinutes: -300,
  offsetSource: 'tzdb' as const,
  offsetAmbiguous: false,
  timeAccuracy: 'exact' as const,
  placeName: 'Ann Arbor, Michigan, US',
  latitude: 42.2808,
  longitude: -83.743,
  elevationM: 256,
  timezoneId: 'America/Detroit',
};

beforeAll(async () => {
  if (!url) return;
  assertSafeToTruncate(url);
  database = createDatabase(url, { max: 4 });
  // Fresh slate. The bypass MUST be transaction-local (`true`): postgres.js
  // pools connections, so a session-level GUC leaks into later queries on the
  // same connection and quietly disables the very isolation under test.
  await database.transaction(async (tx) => {
    await tx.execute(sql`select set_config('app.bypass_rls','on',true)`);
    await tx.execute(
      sql`truncate charts, birth_events, subjects, settings_profiles, memberships, workspaces, users cascade`,
    );
  });
  alice = await bootstrapUser(database, { email: 'alice@example.com', name: 'Alice' });
  bob = await bootstrapUser(database, { email: 'bob@example.com', name: 'Bob' });
});

afterAll(async () => {
  if (!url) return;
  await database.execute(sql`select 1`);
});

describeWithDb('sign-in bootstrap', () => {
  it('gives a new user a workspace and a default settings profile', () => {
    expect(alice.workspaceId).toBeTruthy();
    expect(alice.userId).not.toBe(bob.userId);
    expect(alice.workspaceId).not.toBe(bob.workspaceId);
  });

  it('is idempotent — signing in again reuses the same workspace', async () => {
    const again = await bootstrapUser(database, { email: 'alice@example.com', name: 'Alice' });
    expect(again.workspaceId).toBe(alice.workspaceId);
    expect(again.created).toBe(false);
  });
});

describeWithDb('subjects', () => {
  it('creates a person together with their birth moment', async () => {
    const created = await createSubjectWithBirthEvent(database, alice.workspaceId, {
      subject: { displayName: 'Jade', relationship: 'partner', createdBy: alice.userId },
      birthEvent: birthEventFixture,
    });
    expect(created.subject.displayName).toBe('Jade');
    expect(created.birthEvent.utcOffsetMinutes).toBe(-300);
    // The wall clock survives the round trip exactly as written.
    expect(created.birthEvent.localDatetime).toBe('2001-11-07T10:32:00');
  });

  it('lists only that workspace’s people', async () => {
    await createSubjectWithBirthEvent(database, bob.workspaceId, {
      subject: { displayName: 'Someone Else', createdBy: bob.userId },
      birthEvent: birthEventFixture,
    });
    const aliceList = await listSubjects(database, alice.workspaceId);
    const bobList = await listSubjects(database, bob.workspaceId);
    expect(aliceList.map((r) => r.subject.displayName)).toEqual(['Jade']);
    expect(bobList.map((r) => r.subject.displayName)).toEqual(['Someone Else']);
  });

  it('exports everything about a person as portable JSON', async () => {
    const [first] = await listSubjects(database, alice.workspaceId);
    const exported = (await exportSubject(database, alice.workspaceId, first!.subject.id)) as {
      exportedFormat: string;
      birthEvents: unknown[];
    };
    expect(exported.exportedFormat).toBe('jade.subject.v1');
    expect(exported.birthEvents).toHaveLength(1);
  });

  it('soft delete hides a person; hard delete removes them', async () => {
    const created = await createSubjectWithBirthEvent(database, alice.workspaceId, {
      subject: { displayName: 'Temporary', createdBy: alice.userId },
      birthEvent: birthEventFixture,
    });
    await softDeleteSubject(database, alice.workspaceId, created.subject.id);
    expect(
      (await listSubjects(database, alice.workspaceId)).map((r) => r.subject.displayName),
    ).not.toContain('Temporary');
    // Soft-deleted rows are still fetchable by id — that is what makes undo possible.
    expect(await getSubject(database, alice.workspaceId, created.subject.id)).not.toBeNull();

    await hardDeleteSubject(database, alice.workspaceId, created.subject.id);
    expect(await getSubject(database, alice.workspaceId, created.subject.id)).toBeNull();
  });
});

describeWithDb('row-level security is real, not decorative', () => {
  it('a query with NO where clause still cannot see another workspace', async () => {
    // This is the whole point. If someone writes `select * from subjects` and
    // forgets to scope it, Postgres must return only the bound workspace.
    const rows = await withWorkspace(database, alice.workspaceId, async (tx) =>
      tx.select().from(subjects),
    );
    expect(rows.length).toBeGreaterThan(0);
    for (const row of rows) expect(row.workspaceId).toBe(alice.workspaceId);
    expect(rows.map((r) => r.displayName)).not.toContain('Someone Else');
  });

  it('refuses to write a row into someone else’s workspace', async () => {
    // Drizzle wraps driver errors, so the Postgres message lives on the cause.
    // Assert against the whole chain rather than the wrapper's summary.
    let message = '';
    try {
      await withWorkspace(database, alice.workspaceId, async (tx) =>
        tx.insert(subjects).values({ workspaceId: bob.workspaceId, displayName: 'Smuggled' }),
      );
    } catch (error) {
      const chain: string[] = [];
      let current: unknown = error;
      for (let depth = 0; current instanceof Error && depth < 5; depth += 1) {
        chain.push(current.message);
        current = (current as Error & { cause?: unknown }).cause;
      }
      message = chain.join(' | ');
    }
    expect(message, 'the insert should have been refused').not.toBe('');
    expect(message).toMatch(/row-level security/i);

    // And the row really is absent, not merely reported as refused.
    const smuggled = await withWorkspace(database, bob.workspaceId, async (tx) =>
      tx.select().from(subjects),
    );
    expect(smuggled.map((row) => row.displayName)).not.toContain('Smuggled');
  });

  it('reads nothing at all when no workspace is bound', async () => {
    const rows = await database.select().from(subjects);
    expect(rows).toEqual([]);
  });

  it('the connecting role is not a superuser, so the checks above mean something', async () => {
    const result = (await database.execute(
      sql`select rolsuper, rolbypassrls from pg_roles where rolname = current_user`,
    )) as unknown as Array<{ rolsuper: boolean; rolbypassrls: boolean }>;
    expect(result[0]!.rolsuper).toBe(false);
    expect(result[0]!.rolbypassrls).toBe(false);
  });
});

describeWithDb('place search', () => {
  it('finds a seeded city by prefix and by fuzzy match', async () => {
    const exact = await searchPlaces(database, 'Ann Arbor');
    expect(exact[0]?.name).toBe('Ann Arbor');
    expect(exact[0]?.timezoneId).toBe('America/Detroit');

    const diacritics = await searchPlaces(database, 'sao paulo');
    expect(diacritics[0]?.name).toBe('São Paulo');
  });

  it('orders by population when several cities share a prefix', async () => {
    const results = await searchPlaces(database, 'new');
    expect(results.length).toBeGreaterThan(1);
    expect(results[0]!.population).toBeGreaterThanOrEqual(results[1]!.population);
  });

  it('says nothing rather than guessing on a one-letter query', async () => {
    expect(await searchPlaces(database, 'a')).toEqual([]);
  });
});

describe('relationship pair ordering', () => {
  // Pure, so it runs without a database.
  it('is the same pair whichever way round it is given', () => {
    expect(orderPair('b', 'a')).toEqual(orderPair('a', 'b'));
    expect(orderPair('a', 'b')).toEqual({ subjectAId: 'a', subjectBId: 'b' });
  });
});

describeWithDb('relationships', () => {
  it('records a couple once, whichever way round they are added', async () => {
    const jade = await createSubjectWithBirthEvent(database, alice.workspaceId, {
      subject: { displayName: 'Jade Two', createdBy: alice.userId },
      birthEvent: birthEventFixture,
    });
    const nalu = await createSubjectWithBirthEvent(database, alice.workspaceId, {
      subject: { displayName: 'Nalu', createdBy: alice.userId },
      birthEvent: birthEventFixture,
    });

    const first = await createRelationship(database, {
      workspaceId: alice.workspaceId,
      subjectAId: jade.subject.id,
      subjectBId: nalu.subject.id,
      createdBy: alice.userId,
    });
    // The same couple, entered the other way round. This must not make a
    // second row — two rows for one couple drift, and the stale one is the
    // one nobody is looking at.
    const second = await createRelationship(database, {
      workspaceId: alice.workspaceId,
      subjectAId: nalu.subject.id,
      subjectBId: jade.subject.id,
      createdBy: alice.userId,
    });
    expect(second.id).toBe(first.id);

    const listed = await listRelationships(database, { workspaceId: alice.workspaceId });
    expect(listed).toHaveLength(1);
    expect([listed[0]!.a.displayName, listed[0]!.b.displayName].sort()).toEqual([
      'Jade Two',
      'Nalu',
    ]);
  });

  it('refuses to relate a subject to themselves', async () => {
    const [first] = await listSubjects(database, alice.workspaceId);
    await expect(
      createRelationship(database, {
        workspaceId: alice.workspaceId,
        subjectAId: first!.subject.id,
        subjectBId: first!.subject.id,
      }),
    ).rejects.toThrow(/themselves/);
  });

  it('does not leak across workspaces', async () => {
    const mine = await listRelationships(database, { workspaceId: alice.workspaceId });
    const theirs = await listRelationships(database, { workspaceId: bob.workspaceId });
    expect(mine.length).toBeGreaterThan(0);
    expect(theirs).toHaveLength(0);
  });

  it('deletes cleanly', async () => {
    const [only] = await listRelationships(database, { workspaceId: alice.workspaceId });
    await deleteRelationship(database, { workspaceId: alice.workspaceId, id: only!.id });
    expect(await listRelationships(database, { workspaceId: alice.workspaceId })).toHaveLength(0);
  });
});

describeWithDb('schema drift check', () => {
  // A Vercel deploy never touches the database. The build compiles, the deploy
  // succeeds, and every signed-in page then throws because a migration was
  // never run. This check is what turns that into a 503 on /api/health instead
  // of a support message.
  it('reports current against a freshly migrated database', async () => {
    const status = await schemaStatus(database);
    expect(status.expected).toBe(EXPECTED_MIGRATIONS);
    expect(status.latestExpected).toBe(LATEST_MIGRATION);
    expect(status.applied).toBe(EXPECTED_MIGRATIONS);
    expect(status.state).toBe('current');
  });

  it('goes red when the database is behind, and says what to run', async () => {
    // A green tick that cannot go red is worse than no tick at all — it is the
    // exact mistake db:doctor's isolation probe made before it provisioned its
    // own row. So this removes a migration record, checks the alarm sounds,
    // and puts it back.
    const [row] = await database.execute<{ id: number; hash: string; created_at: string }>(
      sql`select id, hash, created_at from drizzle.__drizzle_migrations order by created_at desc limit 1`,
    );
    expect(row).toBeDefined();
    await database.execute(sql`delete from drizzle.__drizzle_migrations where id = ${row!.id}`);
    try {
      const behind = await schemaStatus(database);
      expect(behind.state).toBe('behind');
      expect(behind.applied).toBe(EXPECTED_MIGRATIONS - 1);
      expect(behind.detail).toContain('pnpm db:migrate');
    } finally {
      await database.execute(
        sql`insert into drizzle.__drizzle_migrations (id, hash, created_at)
            values (${row!.id}, ${row!.hash}, ${row!.created_at})`,
      );
    }
    expect((await schemaStatus(database)).state).toBe('current');
  });
});

describeWithDb('watches', () => {
  let watchId = '';

  it('stores a rule as jsonb and reads it back unchanged', async () => {
    const [first] = await listSubjects(database, alice.workspaceId);
    const rule = { kind: 'transitCrossing', transiting: 'Saturn', natalPoint: 'Moon' };
    const created = await createWatch(database, {
      workspaceId: alice.workspaceId,
      subjectId: first!.subject.id,
      rule,
      label: 'Saturn on her Moon',
      createdBy: alice.userId,
    });
    watchId = created.id;
    expect(created.rule).toEqual(rule);
    expect(created.enabled).toBe(true);
    expect(created.horizonDays).toBe(120);

    const listed = await listWatches(database, { workspaceId: alice.workspaceId });
    expect(listed).toHaveLength(1);
    expect(listed[0]!.subject.id).toBe(first!.subject.id);
  });

  it('refuses a horizon outside the allowed range', async () => {
    const [first] = await listSubjects(database, alice.workspaceId);
    await expect(
      createWatch(database, {
        workspaceId: alice.workspaceId,
        subjectId: first!.subject.id,
        rule: { kind: 'ingress', transiting: 'Jupiter' },
        horizonDays: 0,
      }),
    ).rejects.toThrow();
  });

  it('records hits once, however many times the job runs', async () => {
    // The anti-duplicate mechanism, which is the whole reason hit keys are
    // derived from the event rather than from when the job ran. Without it a
    // practitioner is told the same thing every morning for four months.
    const hits = [
      {
        key: 'crossing:Saturn:Moon:2461000',
        occursAt: new Date('2026-01-01T00:00:00Z'),
        title: 'Saturn reaches natal Moon',
        factors: ['first contact'],
      },
      {
        key: 'crossing:Saturn:Moon:2461200',
        occursAt: new Date('2026-07-01T00:00:00Z'),
        title: 'Saturn reaches natal Moon',
        factors: ['pass 2 of the retrograde loop over the same degree'],
      },
    ];

    const first = await recordWatchHits(database, {
      workspaceId: alice.workspaceId,
      watchId,
      hits,
    });
    expect(first).toHaveLength(2);

    const second = await recordWatchHits(database, {
      workspaceId: alice.workspaceId,
      watchId,
      hits,
    });
    expect(second).toHaveLength(0);

    // And a genuinely new event still gets through.
    const third = await recordWatchHits(database, {
      workspaceId: alice.workspaceId,
      watchId,
      hits: [
        ...hits,
        {
          key: 'crossing:Saturn:Moon:2461400',
          occursAt: new Date('2027-01-01T00:00:00Z'),
          title: 'Saturn reaches natal Moon',
          factors: ['pass 3 of the retrograde loop over the same degree'],
        },
      ],
    });
    expect(third).toHaveLength(1);
  });

  it('stamps the watch with when it was last evaluated', async () => {
    const [watch] = await listWatches(database, { workspaceId: alice.workspaceId });
    expect(watch!.lastEvaluatedAt).not.toBeNull();
  });

  it('lists upcoming hits in time order, with their subject', async () => {
    const upcoming = await listUpcomingHits(database, {
      workspaceId: alice.workspaceId,
      fromDate: new Date('2020-01-01T00:00:00Z'),
    });
    expect(upcoming.length).toBe(3);
    for (let i = 0; i < upcoming.length - 1; i += 1) {
      expect(upcoming[i + 1]!.occursAt.getTime()).toBeGreaterThanOrEqual(
        upcoming[i]!.occursAt.getTime(),
      );
    }
    expect(upcoming[0]!.subject.displayName).toBeTruthy();
    expect(upcoming[0]!.factors.length).toBeGreaterThan(0);
  });

  it('does not leak watches or hits across workspaces', async () => {
    expect(await listWatches(database, { workspaceId: bob.workspaceId })).toHaveLength(0);
    expect(
      await listUpcomingHits(database, {
        workspaceId: bob.workspaceId,
        fromDate: new Date('2020-01-01T00:00:00Z'),
      }),
    ).toHaveLength(0);
  });

  it('takes its hits with it when deleted', async () => {
    await deleteWatch(database, { workspaceId: alice.workspaceId, id: watchId });
    expect(await listWatches(database, { workspaceId: alice.workspaceId })).toHaveLength(0);
    expect(
      await listUpcomingHits(database, {
        workspaceId: alice.workspaceId,
        fromDate: new Date('2020-01-01T00:00:00Z'),
      }),
    ).toHaveLength(0);
  });
});
