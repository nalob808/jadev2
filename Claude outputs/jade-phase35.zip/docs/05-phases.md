# 05 — Build phases

Each phase has: a **goal**, a **definition of done** (testable), and a **prompt** you can paste
into Claude Code to execute it. Run them in order. Do not start a phase before its predecessor's
tests pass in CI.

Rough solo-with-Claude-Code pacing is given per phase; the honest total to a paid launch is
about four to six months of consistent evenings, and about six weeks to something she uses
every day.

---

## The gate before every push

`pnpm verify` runs exactly what CI runs — `--frozen-lockfile`, format, typecheck, lint, test,
build — in about a minute. Run it before pushing.

Two classes of failure exist **only** in the production build and never in `next dev`:

- **TS2742**, "the inferred type of X cannot be named without a reference to `.pnpm/…`". A
  package whose types appear in an exported signature must be a _direct_ dependency even if
  nothing imports it by name. `tsc --noEmit` does not check declaration emit, so typecheck
  passes and `next build` fails.
- **A `pnpm-lock.yaml` that has drifted from a `package.json`.** Your machine installs anyway;
  CI and Vercel use `--frozen-lockfile` and refuse.

Both reached Vercel once. The `Production build` step in `.github/workflows/ci.yml` is there
so neither does again.

---

## Phase 0 — Rails (2–4 days)

**Goal:** an empty repo that is impossible to build sloppily in.

**Done when:**

- pnpm + Turborepo monorepo with the layout in `01-architecture.md`
- TypeScript strict, ESLint, Prettier, `vitest`, Playwright
- GitHub Actions: typecheck + lint + unit + e2e on every PR
- `apps/web` deploys to Vercel on push; preview URLs on PRs
- Sentry wired with a PII scrubber that drops any field named like birth data
- `legacy/jade-v0.html` committed and openable at `/legacy` for side-by-side comparison
- `CLAUDE.md` and `docs/` committed

> **Prompt:**
> "Read CLAUDE.md and docs/01-architecture.md. Scaffold the Jade monorepo exactly as specified:
> pnpm workspaces + Turborepo, apps/web (Next.js App Router, TypeScript strict, Tailwind with
> the design tokens extracted from legacy/jade-v0.html), apps/worker (Node + Dockerfile),
> packages/astro, packages/atlas, packages/db, packages/ui, packages/interpret. Set up vitest,
> Playwright, ESLint, Prettier, and a GitHub Actions CI that runs typecheck, lint and tests.
> Add Sentry with a beforeSend hook that strips any field matching /birth|natal|dob|lat|lon/.
> Commit legacy/jade-v0.html and serve it at /legacy. No feature code yet."

---

## Phase 1 — The calculation core (3–5 weeks; the real work)

**Goal:** `packages/astro` computes a complete, correct Vedic chart. No UI at all.

Sub-steps, in order:

1. `EphemerisProvider` interface + `astronomy-engine` implementation (so you can start today) +
   `sweph` native implementation behind the same interface.
2. Sidereal conversion, all ayanāṁśa modes, ΔT, apparent positions.
3. Points: 9 grahas **including Rāhu/Ketu**, Asc/MC, outers, upagrahas, special lagnas.
4. Houses: whole sign + Śrīpati + Placidus/KP, bhāva madhya.
5. All 16 vargas.
6. Dignities, combustion, retrogression, avasthās, planetary war.
7. Aṣṭakavarga (BAV, SAV, both śodhana schools, śodhya piṇḍa).
8. Ṣaḍbala, all six sources.
9. Yoga rule engine + the first ~40 yogas with cancellations and citations.
10. Daśās: Vimśottarī (5 levels), Aṣṭottarī, Yoginī, Chara (both variants).
11. Pañcāṅga incl. sunrise conventions, Rāhu Kāla, Choghaḍiyā, muhūrta primitives.
12. Transit scanning, root-finding, ingress/station/lunation/eclipse search.
13. Kūṭa matching and synastry primitives.
14. Varṣaphala/Tājika.

**Done when:**

- The golden fixture suite in `docs/07-accuracy.md` passes at the stated tolerances.
- `swisseph-native` and `swisseph-wasm` agree within 0.5″ across 10,000 random datetimes.
- Every exported function has a doc comment naming its classical source.
- Full chart computation benchmarks under 150 ms.
- **Zero** imports from `db`, `web`, or the network anywhere in the package.

> **Prompt (run once per sub-step, not all at once):**
> "Read docs/03-calculation-spec.md section N. Implement it in packages/astro/src/<area>/ as
> pure functions taking jdUT explicitly. Define the types first in types.ts and show them to me
> before implementing. Then write the implementation plus vitest tests covering: the worked
> examples in the spec, boundary cases (0°, 29°59′, sign cusps, retrograde stations, polar
> latitudes, pre-1900 and post-2100 dates), and the golden fixtures in test/fixtures/. Do not
> touch any other package. Cite the classical source in a doc comment on every exported
> function. Where authorities disagree, implement the variants behind a named option and add a
> row to the disagreement table in docs/03-calculation-spec.md."

---

## Phase 2 — People and persistence ✅ SHIPPED ← **the promise you made her**

**Goal:** the app remembers people. Deploy this the day it works.

**Done when:**

- Postgres + Drizzle with the schema from `02-domain-model.md` (subjects, birth_events, places,
  settings_profiles, charts), RLS on `workspace_id`
- Auth (email + Google), workspaces created on signup
- GeoNames atlas loaded, fuzzy place search, historical timezone resolution with the offset
  source recorded and the ambiguity flag surfaced
- "Add a person" flow that a non-technical person completes in under 60 seconds on a phone
- Person list, person detail, switch between people, delete + export
- Charts computed server-side, content-addressed, cached
- **Deployed at a real URL with her account on it**

> **Prompt:**
> "Read docs/02-domain-model.md. Implement packages/db with Drizzle: schema, migrations, RLS
> policies scoped by workspace_id, and typed query helpers. Then in apps/web add Supabase Auth
> (email + Google), workspace creation on signup, and the subject CRUD flow: list, create, edit,
> delete, export. Build packages/atlas with a GeoNames loader script, trigram place search, and
> timezone resolution via Luxon that returns {offsetMinutes, source, ambiguous} — surface
> `ambiguous` in the UI as a 'verify this time' badge with a manual override and an LMT option.
> Charts are computed on the server via packages/astro and cached in the charts table keyed by
> sha256(birthEvent + settings + astroVersion). Playwright test: sign up, add a person with a
> 1987 Mumbai birth, see a chart, reload, chart is cached."

---

## Phase 3 — The chart workspace ✅ SUBSTANTIALLY COMPLETE

**Shipped so far:** the varga projection in the core (`buildVargaChart` — every
divisional re-seated on its own ascendant, not the rāśi redrawn sixteen times),
North Indian and South Indian charts as hand-written SVG, the ṣoḍaśavarga
contact sheet, and the Vimśottarī column scrolled to the running period.

**Deliberately not shipped: the East Indian (Bengali) chart.** It was built and
rendered correctly as geometry, but the traditional sign arrangement could not
be verified against a reference implementation, and a plausible-looking guess
at a regional convention is exactly the kind of thing a Bengali astrologer
spots in one glance. Cross-check the layout against Jagannātha Hora or Shri
Jyoti Star before rebuilding it. Two verified styles beat three where one is
invented.

**Now shipped as well:** the Western wheel (Phase 14), the bhāva chalit overlay
as dashed spokes, aṣṭakavarga shading on the wheel, notes anchored to chart
elements, and — the last item, carried since this phase was written — **the
transit ring with a time scrubber**.

The scrubber is opt-in rather than always on, which was a decision rather than
an omission. The ring adds nine marks to a circle and the ephemeris that
computes it is about 80 KB of JavaScript; a reader who opened a birth chart
should pay neither. So the natal wheel is still the default and the ring
arrives, with its ephemeris, when someone asks for it. Only transits recompute
while scrubbing: the natal positions, yogas, vargas and aṣṭakavarga are
properties of the birth moment and a rendering control must not be able to
alter a reading.

**Still open in this phase:** Playwright visual-regression screenshots of the
chart styles, and the print stylesheet audit.

**Goal:** rebuild the v0 screens as real components over real data, then go far past them.

**Done when:**

- `packages/ui` has the design system (tokens lifted from v0 — keep the blueprint corners and
  the steel accent; that look is Jade's identity) and the chart SVG components: North, South,
  East Indian, Western wheel
- Chart page: wheel + planet table + yoga panel + daśā column + pañcāṅga, per person, per
  settings profile
- Varga grid, aṣṭakavarga overlay, bhāva chalit toggle
- Transit ring with a **time scrubber** running the WASM provider locally at 60 fps
- Notes attachable to chart elements
- Fully responsive; the wheel is legible and interactive on a phone
- Light and dark themes; print stylesheet correct
- Visual regression tests (Playwright screenshots) on all four chart styles

> **Prompt:**
> "Read docs/04-features.md section A and docs/01-architecture.md. Extract the design tokens
> from legacy/jade-v0.html into packages/ui as CSS variables + Tailwind theme. Build the chart
> rendering components as pure React SVG taking a ComputedChart: NorthIndianChart,
> SouthIndianChart, EastIndianChart, WesternWheel, plus PlanetTable, YogaPanel, DashaColumn,
> PanchangCard, VargaGrid, AshtakavargaOverlay. They must render identically on server and
> client and print correctly. Then assemble the /people/[id]/chart page. Add the transit
> scrubber using the WASM ephemeris provider client-side, with server re-verification before
> anything is saved. Add Playwright visual regression tests for all four chart styles at three
> viewport sizes."

---

## Phase 4 — Relationships ✅ COMPLETE

**Shipped:** aṣṭakūṭa verified against every one of the 11,664 possible pairings
(the technique reads only two nakṣatras and two pādas, so the whole input space
is enumerable); maṅgala doṣa with its cancellations computed alongside it and
returned together; synastry as house overlays both ways plus whole-sign dṛṣṭi;
the two-ring **overlay wheel**; the **shared daśā timeline** with named
convergences; the `relationships` table with RLS; and `/relationships`.

**The convergence rules are four, and they are named**: both running the same
graha, the two running lords in mutual dṛṣṭi, one person's running lord sitting
in the other's seventh, and either running the lord of their own seventh. Each
band carries the rule that flagged it and the placements that produced it. There
is no intensity, no score and no colour scale from good to bad — a highlighted
band is a claim, and a claim has to be decomposable.

**The transit half landed with Phase 5's scanner**, as planned. Jupiter and
Saturn are scanned over each person's natal Moon, natal Venus and the lord of
their seventh, and every contact carries which pass of the retrograde loop it
is — a slow graha crosses a degree up to three times and all three are real
dates. Only the two slow grahas are watched: Mars is over a point in days and
the Moon in hours, and a timeline that flags everything flags nothing.

**Deliberately not shipped: a compatibility score.** Aṣṭakūṭa's total is
displayed as a footnote to its eight components, never as a headline, and
nothing in `packages/astro/src/relations` returns a verdict. An e2e test asserts
that no verdict language appears on the page, which is there to catch the
well-meaning future addition of a "compatibility: 62%" badge.

**Goal:** the module that makes the product personal and sells the most consultations.

**Done when:** aṣṭakūṭa with cancellations, synastry overlay wheel, house overlay, Maṅgala doṣa
(carefully worded), the shared daśā/transit timeline with auto-flagged convergences, and the
private couple's page with its own share link.

> **Prompt:**
> "Read docs/03-calculation-spec.md section 11 and docs/04-features.md section C. Implement
> packages/astro/src/relations (kūṭas with all cancellation rules, synastry aspects, house
> overlays, composite chart, convergence detection across two daśā timelines) with tests
> against the worked examples. Then build the /relationships/[id] page: overlay wheel, kūṭa
> breakdown with every rule shown and explained, and the shared timeline component. Maṅgala
> doṣa output must be phrased as analysis with cancellations shown first — review the copy
> against the tone rules in docs/00-vision.md before shipping."

---

## Phase 5 — Predictive engine and alerts 🔵 CODE COMPLETE, DEPLOY PENDING

**Goal:** Jade tells you things before you ask.

**Shipped so far: the transit scanner.** Ingresses, stations and crossings, each
returned as a bisected root rather than a sample. Verified against Swiss
Ephemeris over two five-year windows a century apart, with an independent
bisection on the reference side — every event count matched exactly, and the
timing spread runs from 0.15 minutes for the Moon to 64.78 for Saturn near a
station. That spread is the interactive provider's position error expressed as
a time, not the scanner's precision, which is why **a stored or printed transit
date must come from the reference provider**. See `docs/07-accuracy.md`.

The retrograde triple pass works and is the reason the module exists.

**Shipped: watches.** Four rule kinds — a transit reaching a natal point, an
ingress, a station, and a daśā beginning — each producing hits that carry the
exact moment, the rule, and the placements. Nothing interprets and nothing says
whether an event is good or bad; a test asserts no hit ever contains that
vocabulary.

Stored in `watches` and `watch_hits` with RLS forced on both. `pnpm watches:run`
is the body of the nightly job, and it is **idempotent**: hit keys are derived
from the event rather than from when the job ran, so a second pass over an
overlapping window finds the same ten events and records none of them. Verified
against a real Postgres — three runs, ten rows.

**Shipped: the /timing screens.** Three of them, each answering one question.

`/timing` is the daśā × transit series. The segments **are** the antardaśās
rather than equal date bins, because a bin boundary falling mid-period splits
one reading in half and joins halves of unrelated ones — every division on the
axis is a real change of period. There is deliberately **no heat**: the word
survived in this roadmap and the thing did not. A gradient from cool to hot is a
verdict about a stretch of somebody's life, which Jade may not make. Each
segment carries a _count of named events_ instead, and the one genuine
correlation — a transit by a graha that also rules the running period — is
marked because it is a fact about the chart rather than an opinion about the
person.

`/timing/search` compiles a set of clauses into the windows where all of them
hold. Ranked by **spread** — how few days separate the conditions — which is
arithmetic anyone can check, and explicitly not a ranking by importance. Six
presets cover the questions practitioners actually ask; the builder teaches
itself by showing how each preset was constructed.

`/timing/sky` is the book-wide screen: every person against today's sky, sorted
by what asked for attention — fired watches first, then the difficult end of the
tārā band. One transiting Moon is resolved for the whole book, so the page is
cheap enough to leave open.

**Still to come in this phase:** the long-running worker on Fly.io and email
digests. Both are deploy-side — the worker code and the nightly job body exist
and are idempotent; the digests need Resend wired to a verified domain.

**Done when:** the worker service runs scheduled scans; watches evaluate nightly; the daśā ×
transit heat timeline renders across decades; event search compiles a query and returns ranked
windows; email digests send; the book-wide sky screen works.

> **Prompt:**
> "Read docs/03-calculation-spec.md section 10 and docs/04-features.md section D. Build
> apps/worker as a Dockerized Node service with pg-boss: nightly job that evaluates all enabled
> watches, a job that precomputes per-year ingress/station/lunation/eclipse tables shared across
> all users, and a job that computes the daśā×transit correlation series for a subject over a
> date range. Add the /timing pages: heat timeline, event search builder, book-wide sky.
> Emails via Resend with React Email templates. Deploy the worker to Fly.io. Include a
> load test: 1,000 subjects × 20 watches evaluated in under 5 minutes."

---

## Phase 6 — The practice layer (3 weeks)

**Goal:** the reason it costs $99.

**Done when:** client book, sessions with auto prep sheets emailed 24h ahead, session console
with anchored notes, branded PDF reports rendered by Playwright from the same components,
revocable client share links, and the prediction ledger with hit-rate analytics.

> **Prompt:**
> "Read docs/04-features.md section E. Implement sessions, notes with anchors, reports, share
> links and predictions per docs/02-domain-model.md. The prep sheet is a scheduled job that
> assembles running daśās, active transits, last session's notes and open predictions into a
> React Email + a stored snapshot. PDF generation runs in apps/worker via Playwright rendering
> the same packages/ui components with a print theme and the workspace's branding. Share links
> are signed, scoped, expiring and revocable, and resolve to a projection — never the raw
> subject row. Add the prediction ledger with resolve flow and per-technique hit-rate stats."

---

## Phase 7 — Billing, polish, launch (2–3 weeks)

**Done when:** Stripe subscriptions with the four tiers and a 14-day Pro trial, usage limits
enforced server-side, onboarding that gets a new user to their own chart in under two minutes,
the marketing site, the public accuracy page, legal pages, and **the Swiss Ephemeris
professional licence purchased and its receipt filed**.

> **Prompt:**
> "Read docs/06-launch.md. Implement Stripe Billing with the four tiers, webhooks, the customer
> portal, Stripe Tax, and server-side entitlement checks in a single `can(workspace, feature)`
> helper used everywhere. Build the marketing site at apps/web/(marketing): landing, pricing,
> the comparison table from docs/00-vision.md, the accuracy page rendering live results from the
> golden test suite, docs, privacy policy, terms including the no-death/health/legal-prediction
> clause, and GDPR export/delete flows. Add PostHog with birth data excluded from all events."

---

## Phase 9 — Rectification ✅

**Goal:** the feature a professional switches software for.

Birth time rectification is the most valuable unsolved problem in this market.
Every practitioner meets clients with "sometime in the morning" on the birth
record, the ascendant is the one thing the whole chart hangs from, and the
existing tools either do not attempt it or produce a single confident number
with no working shown. Astrologers already pay for rectification help. Nothing
good exists.

**Shipped so far: the engine.** A pure sweep over candidate birth times,
scoring each against reported life events by named classical rules. Sixteen
event kinds, each mapped to its houses and kārakas with a citation; seven
scoring rules with fixed, exported weights; every point traceable to the
placements that produced it. The `life_events` table, RLS forced, and the
workspace at `/people/[id]/rectify`.

**The two signals, and why they are the only ones.** Over a window of hours the
ascendant moves about a degree every four minutes and rotates the houses; the
Moon moves half a degree an hour and fixes the balance of the first mahādaśā,
which shifts every daśā boundary in the life. Everything else is still —
Saturn moves two arcseconds an hour. A rule resting on a slow graha's sign
alone fires identically for every candidate and ranks nothing.

**Which is the thing this implementation does that others do not.** The sweep
reports, per rule, the fraction of candidates it fired for, and marks any rule
above 98% or below 2% as non-discriminating. Those rules are shown greyed,
with their firing rate, beneath the ones that actually separated the field. A
rule that fires for everything contributed to every score equally; including it
in a confident-looking spread without saying so is how a tool starts lying
politely. The page also reports **separation** — the best candidate against the
median — and says plainly when the supplied events do not distinguish the
window, which is a fact about the evidence rather than about the chart.

**Deliberately not shipped: an answer.** There is no `bestTime` field on the
result type and no "rectified birth time" anywhere in the UI. The output is a
ranked shortlist, every candidate carries its rules, and `RECTIFICATION_CAVEAT`
travels with it. Adopting a candidate is a separate, labelled act that writes
`min5` accuracy and a source note recording that the time came from a sweep —
because a year later nobody remembers whether an ascendant came from a
certificate or from an inference, and the two deserve very different
confidence.

**On the difficult event kinds.** Bereavement, illness and accident are among
the best rectification anchors there are: precisely dated, unambiguous, and
they engage houses nothing else engages. They are included as _events the
person reports having already happened_ — data, not prophecy. Constitution item
6 forbids predicting death, disease and legal outcomes; it does not forbid
recording that a bereavement occurred in 1998 and asking which birth time is
consistent with it. Nothing in the module produces a forward-looking statement,
and a test asserts it.

**Still to come in this phase:** more rules (Aṣṭottarī cross-check once that
daśā exists, Tājika annual returns once varṣaphala does), a printable
rectification report, and the ability to hold two candidate birth events side
by side rather than adopting one.

**Done when:** the sweep runs over a configurable window and step; events are
stored, excludable and re-runnable; every candidate shows its rules and their
placements; non-discriminating rules are reported as such; a candidate can be
adopted with its provenance recorded; and no output anywhere claims a corrected
time.

> **Prompt:**
> "Read packages/astro/src/rectification. Add the remaining rules behind named
> options, and build the printable rectification report from the same
> components as the chart report. Every rule must return the placements that
> made it fire, weights stay exported, and the discrimination reporting must
> cover any rule you add. Do not add a field that names a single best time."

---

## Phase 10 — Entitlements ✅

**The finding that started it:** nothing in the codebase read `workspaces.plan`. There was no
gating of any kind, which meant the free tier was the entire product and the pricing page was
describing a product that did not exist. That reframes the revenue question. It is not "what
should we build to charge more"; it is **"what should Free stop doing"**.

### The split

Free is your own chart. Paid is doing this work on other people.

|                                                   | Free | Seeker $9 | Practitioner $49 | Professional $99 |
| ------------------------------------------------- | ---- | --------- | ---------------- | ---------------- |
| People                                            | 3    | ∞         | ∞                | ∞                |
| Notes                                             | 10   | ∞         | ∞                | ∞                |
| All 16 vargas, yogas, daśās, aṣṭakavarga, ṣaḍbala | ✅   | ✅        | ✅               | ✅               |
| Export                                            | ✅   | ✅        | ✅               | ✅               |
| Relationships and synastry                        |      | ✅        | ✅               | ✅               |
| Printable reports                                 |      | ✅        | ✅               | ✅               |
| Rectification                                     |      | ✅        | ✅               | ✅               |
| Alerts, sessions, varṣaphala                      |      |           | ⏳               | ⏳               |
| Branding, share links, muhūrta, ledger, API       |      |           |                  | ⏳               |

Free keeps **full calculation depth**, deliberately. A crippled calculator is the wrong thing to
give away when the entire market position is "accuracy is the product" — the free tier has to be
the thing that proves the claim. What Seeker sells is scale and the practice layer.

### What may and may not be gated

The pricing page promises "accuracy is not a paid feature". That is a promise about
_correctness_, not scope: every tier computes the same chart, with the same ephemeris and the
same ayanāṁśa maths. Gating which **pages** a workspace may open is fine. Computing a cheaper,
less accurate chart for a free workspace never is, and `plans.ts` has no vocabulary that could
express it. Constitution item 1.

**Export is not gateable at all.** Constitution item 4 requires export on every plan, and
"always" does not mean "on the tiers that paid for it". There is deliberately no capability key
for it, so the guarantee is structural rather than a matter of remembering. An early draft of
this phase gated export to Seeker; that was wrong and was removed.

### Design decisions worth keeping

- **One table, two consumers.** `apps/web/src/lib/plans.ts` is read by both the marketing
  pricing page and the server-side gate. A tier list maintained twice eventually advertises
  something the product does not grant, and the person who finds the gap is always a customer.
- **Cumulative by construction.** A tier declares only what it _adds_; "everything in Seeker" is
  true because `capabilitiesOf` walks the ladder, not because someone copied bullets down.
- **`built: false` is data, not a footnote.** An unfinished capability renders with a "being
  built" tag automatically. A test asserts that nothing unbuilt sits on Seeker — the only tier
  anyone can actually be charged for today.
- **Enforcement is server-side or it is decoration.** Every gate runs in a page body or a server
  action. The e2e suite navigates directly to gated URLs, because that is what a bookmark does.
- **A refusal explains itself.** `/upgrade` always answers four things: what was blocked, what
  that feature does, which is the _cheapest_ tier with it, and what you are on now.
- **Unknown tier strings degrade to Free, visibly.** Throwing takes the workspace down; granting
  everything turns one typo into free Professional. Free is the recoverable direction — and
  Settings prints the raw stored value so a mis-flagged paying customer can see it.
- **Grandfathering, in the migration.** Every workspace that existed when 0009 ran is on
  Professional at no charge, marked `plan_source = 'grandfathered'`. Taking features away from
  people who signed up when everything was included, to tidy a pricing page, is not a trade
  worth making.
- **`plan_source` exists so billing cannot cancel comped accounts.** When the Stripe webhook
  lands, "no active subscription" and "should be free" are not the same fact. Conflating them
  downgrades every grandfathered and comped workspace at once.

### The honest state of the ladder

Only **Free → Seeker** is a real, chargeable upgrade today. Everything on Practitioner and
Professional is `built: false`. Do not open checkout on those tiers until they are not.

### Instead of a fake Buy button

There is no checkout, so the wall does not pretend there is one. It offers "tell me when this
opens", which writes a row to `upgrade_intents` recording the tier they were on, the tier they
wanted, and the gate that refused them. That is the only unbiased demand signal this product can
currently generate, and it doubles as the list of people to email on the day billing opens.

### Acceptance

- 65 web unit tests including 23 on the matrix; 56 e2e including 7 on the gate.
- Invariant tests, not just value tests: no tier may remove a capability or lower a limit
  relative to a cheaper one; every capability is sold on exactly one tier; no tier allows zero
  of anything.
- `pnpm db:doctor` now checks `life_events` and `upgrade_intents`, **and fails on any
  workspace-scoped table missing from its own list** — the list had already fallen behind twice.
- Migration 0009 also normalises 0008's `life_events` policy onto the two helper functions every
  other policy uses. Written as a new migration rather than an edit, because 0008 is recorded as
  applied on any database that has run it.

> **For the next agent:** do not add a capability key for export, and do not gate a calculation.
> If you add a workspace-scoped table, add it to `expected` in `packages/db/scripts/doctor.ts`
> — the doctor will fail until you do, which is the point. When wiring Stripe, write
> `plan_source = 'stripe'` and never downgrade a row whose source is `grandfathered` or
> `manual`.

---

## Phase 11 — Billing, and the two pages that must ship with it ✅

Phase 10 built the gate. This makes it possible to pay to pass, and writes the
two documents you should not take a card without.

### Stripe

- **Checkout** creates the customer _before_ the session and attaches it to the
  workspace, so the webhook arriving seconds later can find the account. A
  payment you cannot match to an account is the classic version of this bug.
- **The webhook** verifies the signature against the raw body (`request.text()`,
  never `request.json()` — re-serialising changes the bytes), answers 200 to
  events it deliberately ignores so Stripe does not retry-storm the endpoint,
  and claims the event id in `stripe_events` _before_ acting.
- **The billing portal** is Stripe's, not ours. Cards, cancellation, invoices
  and receipts all live there. Every billing screen not built is one that
  cannot leak a card number.
- **All of it is optional.** With no keys set, `billingConfigured` is false, the
  Stripe SDK is never loaded, and the wall keeps offering to record interest.
  This is a tested state, not a degraded one — see `legal-and-billing.spec.ts`.

### The decision is pure, and that is the point

`lib/billing.ts` has no network, no database and no Stripe import. It is the
piece of the system that can take somebody's product away, and a rule that can
only be exercised by replaying live webhooks is a rule nobody exercises.

Two guarantees it enforces, both tested exhaustively:

1. **Billing may only change what billing created.** A workspace whose
   `plan_source` is `grandfathered` or `manual` is untouchable by any Stripe
   event — including an upgrade, because a guard that works in one direction
   only is not a guard. "No active subscription" and "should be Free" are
   different facts, and conflating them cancels every comped account at once,
   silently, starting with the people who trusted you earliest.
2. **`past_due` keeps access.** The card failed and Stripe is retrying for
   about a fortnight. Cutting a paying customer off on the first failed retry
   loses both the customer and the payment that would have recovered.

An unrecognised price resolves to nothing rather than to a guess — a live-mode
price arriving at a test-mode deployment looks exactly like that, and guessing
either gives the product away or removes something just paid for.

### Terms and Privacy

`/terms` carries the never-predict rule in writing, which is the half of
constitution item 6 that was never built. `/privacy` says what Jade actually
holds, who processes it, and how to get it all back.

**The privacy policy states plainly that birth data is not yet encrypted at the
field level.** Storage is encrypted by the host; the fields are not, so anyone
with a live connection string can read a birth time. Writing "your data is
encrypted" and letting the reader infer the stronger meaning would have been
the most quotable false sentence on the site, in the document people read when
deciding whether to trust us with somebody else's birth certificate. An e2e
test asserts that sentence is absent and the honest one is present.

### Acceptance

- 83 web unit tests (18 new, on the billing rules); 63 e2e (7 new).
- `pnpm db:doctor` gained a reasoned exemption list — `stripe_events` carries a
  `workspace_id` but is deliberately not RLS-scoped, because the webhook has no
  session to bind, and the doctor now _prints that reason_ rather than staying
  silent about it.
- `docs/09-stripe.md` is the setup checklist for the part only a human can do.

> **For the next agent:** never let a Stripe event write to a workspace whose
> `plan_source` is not `default` or `stripe`. The guard is in
> `resolvePlanChange` _and_ repeated in the SQL `WHERE` clause of
> `applyBillingState`; keep both. And do not update the encryption paragraph in
> `/privacy` until field-level encryption actually ships.

### Still true, and still the constraint

Only **Free → Seeker** is chargeable. Everything above it is `built: false`.
Create the Seeker prices in Stripe and leave the rest — a tier with no price id
falls back to "tell me when this opens" on its own.

---

## Phase 12 — Sessions and prep sheets ✅

**The first Practitioner capability that stops being a promise.** Everything on
that tier was `built: false`; this one is now true, and the pricing card and
the upgrade wall pick that up from the same flag automatically.

### Why this one and not another technique

The $100 test asks whether a feature saves a working astrologer an hour a week.
A prep sheet is the only thing in the backlog that answers it directly: an hour
before every reading currently goes on assembling by hand what the software
already knows.

The obvious version of this feature is worthless — it prints the chart again,
and the practitioner already knows the chart. What they cannot get in five
minutes is:

1. **When the daśā next turns.** Not "Venus–Saturn", which they remember — the
   date the antara ends, which they are asked in almost every reading and work
   out by hand almost every time.
2. **The dated transit contacts either side of the appointment**, with every
   pass of a retrograde loop, because those are the dates that get written down
   and handed over.
3. **What was said last time**, which after forty clients is genuinely
   unrecoverable.

### The line this feature must not cross

A prep sheet lists what is _there_. It never says what a period means for the
person, never rates one, and never suggests what to tell them. The moment it
does it stops being preparation and becomes a script — and a script read out by
a practitioner who has not checked it is exactly what makes generated astrology
worthless. Both the unit and e2e suites assert the absence of that vocabulary
on a page a practitioner reads aloud from.

### Decisions worth keeping

- **Aspects are deliberately absent from the diary.** Vedic aspect is primarily
  rāśi dṛṣṭi, so "Saturn aspects her Moon" stays true for about two and a half
  years. It is a standing condition, not a dated event, and listing it under
  "around 12 September" would misrepresent it as news. Standing conditions
  belong in the chart reading, which already covers them.
- **Only slow bodies.** The Moon changes sign every two days; listing its
  contacts would bury the four that matter under sixty that do not.
- **The prep sheet is computed, never stored.** A stored sheet silently rots —
  correct the birth time or change the ayanāṁśa and last month's sheet still
  shows last month's answer.
- **`notes.session_id` is a LINK, not an anchor.** Anchors name stable factors
  ("Mars", "the 7th") precisely so a note can be found from any chart sharing
  that factor. A row id is not a factor, and adding `session` to the anchor
  vocabulary would have broken that invariant for a convenience.
- **A follow-up outlives its session** — nullable `session_id`, ON DELETE SET
  NULL. "Revisit the 10th when Saturn stations" is still true after the
  consultation record is tidied away.
- **`scheduledFor` is a real instant**, unlike birth data, which stores a wall
  clock as text. A birth certificate's characters are the record; a
  consultation is a moment two people must both turn up for. The difference is
  deliberate, and booking runs through the same offset resolver birth data uses
  rather than a second, simpler conversion.
- **`getSessionById`, not `getSession`.** "Session" means both the signed-in
  user's session and a consultation, and the page rendering one imports both.
  One `getSession` in scope resolving to the wrong one is a bug that typechecks.

### Acceptance

- 56 interpret tests (13 new) and 585 astro; 69 e2e (6 new). `pnpm verify` green.
- The multi-pass test is **pinned to a window where a retrograde loop is a fact**
  — over the 180 days a prep sheet covers, the reference chart happens to have
  none, so asserting there would have tested the calendar rather than the code.
- `pnpm db:doctor` caught `sessions` and `follow_ups` as unlisted
  workspace-scoped tables before they shipped. That check was added in Phase 10
  for exactly this, and it worked on its first real opportunity.

> **For the next agent:** do not let the prep sheet start advising. If you add
> graha dṛṣṭi by degree, give it its own section with its own stated orb rather
> than mixing it into the contact diary — the diary's whole value is that every
> line in it is an exact date.

---

## Phase 13 — The public chart library ✅

A front door that shows the product before asking for anything. Jade previously
asked you to sign up and _then_ to type a birth certificate before it would show
you a single chart.

### The finding that shaped the whole feature

The roster is 19 figures. **Exactly one has an attested birth time.**

That is not a seeding shortcut, it is what the evidence supports.
Encyclopaedias record the date and place of a birth and almost never the hour.
Times for famous people circulate widely in astrological literature, usually
with no primary source and frequently disagreeing with each other by hours —
Gandhi has several in circulation that differ by more than an hour, and the
astrologers publishing Ramanujan's own call it tentative.

So the _dominant_ case in any honest public library is the untimed one, and the
whole design follows from taking that seriously rather than papering over it.

### What an untimed chart shows

`positionsAcrossDay` computes what a date alone actually determines, by
evaluating both ends of the local day and reporting whether they agree:

- **The ascendant is unknowable** — it travels the whole zodiac in a day, and so
  does every house counted from it. The result type contains no ascendant and no
  houses, so a caller cannot read one out by accident.
- **The Moon usually is too** — about 13° a day against a 13°20′ nakṣatra, so it
  changes nakṣatra almost daily.
- **The slow grahas are fine** — Saturn moves about two arcminutes. Reporting it
  as uncertain would be as wrong as inventing a lagna.

A graha that holds its sign all day is reported as certain; one that crosses a
boundary is reported as _both_ signs, which is the true answer and more useful
than either half.

Most software resolves this tension by dropping the refusal: assume noon, draw a
confident ascendant, print it identically to a chart from a birth register. A
student cannot tell the two apart, which makes the software actively harmful for
the one thing they are trying to learn. An e2e test asserts no lagna appears on
an untimed page — and asserts it on the _labels_, not on the word "ascendant",
because the honest disclosure legitimately uses that word and a substring check
would be satisfied by deleting the honesty.

**The missing time is then framed as a question rather than a dead end**, linking
to rectification — which turns our weakest data into the one feature no
competitor has.

### Why `public_figures` is its own table

The obvious design is `subjects.is_public`. It is wrong for a safety reason.

`subjects` holds clients' birth data behind row-level security. The library
reads with no session and no workspace binding, so putting public figures there
means either poking a hole in the isolation policy or running library queries
with RLS bypassed — both of which put one bad predicate between a private client
and a page indexed by Google.

With two tables the library's queries never mention `subjects` at all, so the
leak is **unexpressible rather than merely guarded against**. A test asserts it
through the front door anyway.

The table also carries no `workspace_id`, so `db:doctor`'s unlisted-table probe
has nothing to find and needs no exemption — noted in the doctor where somebody
would look for it.

### Decisions worth keeping

- **The Rodden rating is NOT NULL, and `X` is a legitimate answer.** A CHECK
  constraint enforces that a row rated X or XX has no time and a rated row does,
  so the invariant holds against a hand-written INSERT.
- **The lens is fixed and printed on every page.** No session means no settings
  profile; constitution item 3 forbids a _silent_ default, not a default.
- **Zones resolve through the tz database.** Calcutta kept Howrah Mean Time at
  +05:53:20 until 1941 — software assuming +05:30 puts every 19th-century Indian
  birth twenty-three minutes out.
- **Newton is stored as 4 January 1643**, the Gregorian equivalent of the Julian
  25 December 1642 England was still using, with the note printed beside the
  chart.
- **Summaries are written for Jade, never pasted.** The encyclopaedias they would
  otherwise come from are variously licensed, and a library built on copied prose
  is one that has to be taken down.

### Acceptance

- 593 astro tests (8 new on the untimed day); 78 e2e (9 new). `pnpm verify` green.
- `pnpm --filter @jade/db seed:figures` upserts on slug, so correcting a record
  is editing `packages/db/data/publicFigures.ts` and re-running.

> **For the next agent:** never add a birth time to `publicFigures.ts` without a
> source in `timeSource`, and never lower a rating to make a chart look better.
> If you add a figure whose time you found on an astrology site with no primary
> source, that is `C` at best and probably `X`. The library's only real asset is
> that its ratings can be trusted.

### Still open

The roster is small and heavily untimed. Growing it is research, not code —
every entry needs its date and place checked and its time either sourced or
honestly marked absent.

---

## Phase 14 — The wheel, given a room of its own ✅

The wheel used to be a figure part-way down a person's page, below the
positions table and above the reading. It is the thing an astrologer actually
looks at, so it now has `/wheel`: the chart centre stage, the people to switch
between on one side, and everything about the selected graha on the other.

### The glyphs are drawn now, and that was a real bug

The wheel printed the Unicode zodiac block — ♈ ♉ ♊ — which is the obvious
implementation and is wrong on exactly the devices this most needs to look
right on. Those code points have **emoji presentations on iOS**, so an iPhone
rendered some signs as flat monochrome type and others as full-colour emoji, at
a different optical size and baseline, varying by OS version. Android
substituted from whatever fallback font it had. None of it was reachable from
CSS, because the glyph came from a font the page never chose.

`packages/ui/src/glyphs.tsx` draws all twenty-two — twelve signs, nine grahas,
plus a mark for the lagna — from primitives: circles, arcs and strokes, which is
how these glyphs are actually built typographically. Venus is a circle over a
cross; Aquarius is two waves. Written that way each one can be read and adjusted
by a person, where a 400-character `d` attribute cannot. They render identically
everywhere, scale without hinting artefacts, and inherit `currentColor`.

An e2e test asserts no Unicode sign character appears anywhere on the page.

### Colour that encodes rather than decorates

Signs tint by classical element, grahas by classical nature — benefic, malefic,
neutral. Both got **their own tokens** rather than reusing `--accent` and
`--jade`, which carry interface meaning: a chart that borrows them makes Fire
mean the same thing as a button. Muted rather than saturated, because twelve
strong wedges around a circle stop being information and become a colour wheel.

### One selection, shared

Click-to-isolate, coordinated highlighting and the people rail are three views
of one piece of state. Selecting Saturn dims the wheel, filters the dṛṣṭi, and
fills the panel together — and the e2e test asserts it in **both** directions,
because a selection that only travels one way is two widgets, not an
instrument.

Selection was **lifted, not built**: the wheel already had internal `selected`
state with click and keyboard handling. `focus` and `onFocusChange` are optional
props that switch it to controlled, so the printable report and the public
library keep their self-managing wheel untouched. `undefined` means
uncontrolled and `null` means controlled-with-nothing-selected, and the
difference matters.

### The focus index

Everything about a graha — dignity, combustion, bindus, the yogas it forms with
their cancellations, the periods it rules, the notes anchored to it — gathered
server-side into one object per chart. None of that data is new; it was spread
across six sections of the person page that did not know about each other, so a
practitioner asking "what about Saturn?" answered it by scrolling and
remembering.

Yoga membership matches against the yoga's computed `factors`, not its prose
summary — the summary mentions grahas it is only contrasting with, so matching
it would report "Saturn is mentioned" as "Saturn is involved".

### Overlay

A second person rides the outer ring, reusing the main wheel's existing transit
ring rather than swapping to `OverlayWheel`. The workspace wants one wheel that
behaves the same way whether or not a second chart is on it. `OverlayWheel`
stays for the relationship page, where two charts are read as equals rather than
one against the other's houses.

### Honesty carried through

The wheel prints its lens, and prints a caveat when the birth time is uncertain
— "uncertain by a couple of hours, which is long enough for the lagna to have
changed sign". A drawing implies precision that a table does not, so the wheel
needs the warning more, not less.

### Acceptance

- 798 unit tests; 83 e2e (5 new). `pnpm verify` green.
- Touch targets went from r=3.4 to r=4.6 in the 100-unit box — roughly the 44px
  minimum on a phone-sized chart. Comfortable with a mouse was fiddly with a
  thumb.

> **For the next agent:** keep `focus` optional on the Wheel — three surfaces
> render it and only one is a workspace. And do not reintroduce Unicode glyphs
> for "simplicity"; the test that forbids them is guarding a real iOS failure.

### Not done, carried forward

The **time scrubber** was planned for this phase and is not in it — the wheel
page, the glyph system and the focus model filled it. The groundwork is laid:
selection is lifted, the transit ring already accepts arbitrary points, and
`packages/astro` runs in the browser.

---

## Phase 16 — One instrument, reachable from anywhere

**16.1 and 16.4 are done** — shipped together, because a wheel that behaves the
same everywhere and a vocabulary that explains itself everywhere are the same
complaint. See the notes under each below.

Seven requests came in together, and they are not seven features. They are one
complaint said seven ways: **Jade has good parts that do not know about each
other.** There are two different wheels. The public library exists and is
linked from nowhere a signed-in user will ever look. Words explain themselves
on two pages out of fifteen. Nothing remembers what you were doing.

That is a problem for everyone and a much bigger one for the person this phase
is explicitly designed for.

### The brief: built for an ADHD reader

This is a design constraint with teeth, not a garnish, and it decides several
arguments below. Four rules, applied throughout:

1. **One obvious action per screen.** Not fewer features — fewer _decisions_
   before the first useful thing happens.
2. **State is visible, never remembered.** If something is selected, filtered,
   or hidden, the screen says so. Nothing depends on the reader holding
   context between pages.
3. **Every surface is a way in, never a dead end.** A thing you can see is a
   thing you can click, and it takes you somewhere related.
4. **Colour and motion are information or they are removed.** Decoration
   competes with the signal for the same attention, and loses it for
   everybody.

There is a real tension between this brief and two of the requests — more
theme choices and more chart colours both add visual load. §16.2 and §16.6
say exactly how each is resolved rather than pretending the tension is not
there.

---

### 16.1 — One wheel, everywhere

**The problem.** `packages/ui/src/charts/Wheel.tsx` is rendered twice with
wildly different capability. `/wheel` wraps it in `WheelWorkspace`: focus
state, the people rail, the overlay picker, the focus panel. The person page
drops the bare component into a `max-w-[560px]` box with no focus, no panel,
and no way to do anything with a click. Same component, two products, and the
reader has to learn which page they are on before they know what the chart
can do.

**The work.**

- Extract `WheelWorkspace` into a component both surfaces mount, and give the
  person page the full one. The person page keeps its positions table, vargas
  and reading below; the wheel section becomes the same instrument as `/wheel`.
- Keep the bare `Wheel` for the printable report and the public library —
  those are documents, not workspaces, and a focus panel in a PDF is noise.
  This is the existing controlled/uncontrolled split and it stays.
- Move the layer toggles (house numbers, glyphs, degrees, dṛṣṭi, nakṣatra
  divisions, element tint, aṣṭakavarga) into the shared component so both
  surfaces get all of them.
- **Persist the toggles and the selection in the URL**, not in component
  state. This is rule 2: a reader who follows a link, reloads, or comes back
  tomorrow finds the chart as they left it, and can send someone the exact
  view they are looking at.

**Acceptance.** An e2e test opens a person page, turns on aṣṭakavarga, selects
Saturn, reloads, and finds both still true. The same test passes against
`/wheel` with the same selectors, because it is the same component.

**Done.** `WheelWorkspace` takes a `variant`: `workspace` for `/wheel` (with
the people rail and the overlay picker) and `inline` for the person page, where
the subject is already decided and a rail of other people is an invitation to
leave. Everything else is identical. The selection lives in the URL as `?g=`,
so a reload keeps it, the back button walks selections rather than leaving the
page, and "look at her Saturn" is a link instead of instructions.

---

### 16.2 — Bigger, and readable at a glance

**Size.** The wheel is capped at 560px on the person page and shares its row
on `/wheel`. It becomes the widest thing on the page, sized from the viewport
rather than a fixed max, with the side panels collapsing under it on narrow
screens instead of squeezing it.

**Aspect lines get colour — encoding source, not inventing a dimension.**
Today every dṛṣṭi line is `--accent` at two widths. Following a line back to
the graha that cast it means tracing it by eye across a crowded circle.

The rule: **an aspect line is the colour of the graha that casts it**, reusing
the nature tints already defined. Nothing new is introduced into the palette,
and the line is legible as "that is Saturn's" without a legend.

Special dṛṣṭis — Mars to the 4th and 8th, Jupiter to the 5th and 9th, Saturn
to the 3rd and 10th — are **dashed**, with the universal 7th-house aspect
solid. That is deliberately redundant with colour: shape survives
colourblindness, printing, and a phone in sunlight, and colour-alone encoding
fails all three.

**Colour discipline.** Element tint on the sign ring, nature tint on the
grahas, source tint on the aspects — three systems, each answering a different
question, none of them decorative. When a graha is selected everything else
desaturates rather than disappearing, so the context stays available without
competing.

**Acceptance.** With dṛṣṭi on and nothing selected, the lines from Mars are a
different colour from the lines from Jupiter, and Jupiter's 5th/9th lines are
dashed while its 7th is solid. Asserted in the DOM, not by screenshot.

---

### 16.3 — The time scrubber ✅ DONE

**Built as part of closing Phase 3**, since it was that phase's last open item
and this phase's largest risk. See the Phase 3 note above for the two decisions
that shaped it: the ring is opt-in, and its ephemeris is fetched on demand
rather than shipped to every chart page.

Groundwork existed: selection is lifted, the transit ring already accepts
arbitrary points, and `packages/astro` runs in the browser because it is pure
(constitution #2 earning its keep — this is where it cashed out).

- A date control under the wheel: drag to move the transit ring, with buttons
  for today / a week / a month / a year, and a date field for a specific day.
- **Only transits recompute.** The natal chart is fixed; seven bodies move.
  Recompute on animation frames, and never recompute the natal positions,
  the yogas, the vargas or the aṣṭakavarga — those do not change.
- The daśā chain updates alongside the ring, because "what is running when
  Saturn gets there" is the actual question being asked.
- The scrubbed date is in the URL like everything else in §16.1.
- **The scrubber returns to today with one click, and says when it is not on
  today.** A chart silently showing a date you set twenty minutes ago and
  forgot is a correctness problem, not a UI wrinkle.

**Acceptance.** Scrubbing forward one year moves a slow graha by roughly the
right amount against a golden fixture, the natal ring does not move, and the
"not today" state is announced.

---

### 16.4 — Explanations everywhere

Phase 15 built the glossary and wired it into `/wheel`, the person page and
section headings. It stops there.

- **Home page**: the week bands, the running daśā chain, the sky panel and
  the daily reading all print technical vocabulary with no way in.
- **Person page**: extend past the headings into the positions table, the
  varga grid, the pañcāṅga card and the aṣṭakavarga panel — the places where
  the words are densest and least explained.
- **New entries** for what those surfaces actually say: tārā and candra bala
  by name, vāra, karaṇa, nitya yoga, upachaya, maraka, cazimi, retrogression,
  and each of the sixteen vargas.
- **Breakdowns, not just definitions.** Where a number is computed —
  a bindu count, a ṣaḍbala component, a tārā — the card shows the arithmetic
  that produced it, not only what the word means. This is constitution #5
  applied to the interface itself: a figure that cannot show its working
  should not be on screen.

**Done, and pulled forward into 16.1 at Nalu's request.** The change that made
it work was _scoping_. `glossaryContextFor` answers "what does nakṣatra mean in
this chart", which is right for a heading and wrong for a table cell: the word
`Nakṣatra` in Saturn's row is asking about Saturn. So context now comes in two
layers — `packages/interpret/src/glossaryScope.ts` builds a scope per graha,
per house, per sign and per varga, and a `<Scope of="Saturn">` narrows every
term inside it. One scope answers many different terms, because the _word_
decides what the scope means: inside Saturn's row, `dignity` is Saturn's
dignity, `dṛṣṭi` is what Saturn aspects, and `daśā` is the periods Saturn
rules.

The vocabulary went from 35 entries to about 140. Most of that is _derived_
rather than written: the twelve signs, nine grahas and twelve houses are
generated from the significations libraries, so the lesson and the tooltip
cannot drift, and the twenty-seven nakṣatras and nine tārās were added with
their reference facts. Every sign, graha, house, nakṣatra and tārā name printed
anywhere in Jade is now hoverable.

---

### 16.5 — Public charts, inside the account

The library is nineteen figures with a genuinely honest treatment of birth-time
provenance, and from inside the app it is reachable only by typing the URL.

- **A nav entry in `Shell`**, beside People — the app's own nav, not just the
  marketing header.
- **On the home page**: "born on this day", drawn from the library, which is
  the one thing that changes daily and gives a reason to come back.
- **From the wheel's people rail**: a second section under your own people, so
  a public figure can be loaded into the same wheel — and therefore overlaid
  against a client's chart, which is a real technique and currently
  impossible.
- **From `/people`**: a way to open a library chart without adding it to your
  own list, since it is not your client and should not count against your plan.

The private/public table separation from Phase 13 is **not** relaxed. These
are read paths into `public_figures`; nothing writes a client into it, and
nothing joins the two.

---

### 16.6 — Theme vibes

**The resolution of the tension.** A theme changes **ground, ink, accent,
rule and texture**. A theme never changes **what a colour means**. Fire is
always the warm one, malefic is always the clay one, Saturn's aspect lines are
always Saturn's colour — but each theme supplies its own tuned values for
those roles, so the chart belongs to the theme rather than looking pasted onto
it. Semantics fixed, values themed.

Starting set, each a complete token block in `globals.css`:

| Theme                     | Ground                        | Character                              |
| ------------------------- | ----------------------------- | -------------------------------------- |
| **Paper** (current light) | Warm off-white                | The default; print-like                |
| **Ink** (current dark)    | Deep blue-black               | The default dark                       |
| **Palm**                  | Warm sand, jade accents       | Hawaiian — deliberately Nalu's         |
| **Dusk**                  | Muted plum-grey               | Low-contrast evening                   |
| **Ash**                   | Neutral grey, near-monochrome | Minimum colour load — the ADHD default |
| **Vellum**                | Cream, brown ink              | Manuscript                             |

- Stored on the settings profile (a migration), so it follows the account
  rather than the browser, with the existing light/dark toggle still
  overriding per-device.
- Picked in Settings → Appearance **with a live preview of a real wheel**, not
  a row of colour swatches. You are choosing how your instrument reads, and
  swatches cannot tell you that.
- `prefers-reduced-motion` is honoured everywhere, and the scrubber's
  animation is the first thing it turns off.

**Acceptance.** A test asserts every theme defines every token — a theme with
a hole falls back to another theme's colour and produces a chart that is
subtly, invisibly wrong.

---

### 16.7 — The ADHD pass

Specific items, beyond the rules already applied above:

- **Resume where you were.** Home leads with the chart you last had open and
  the view you had set, as the first thing on the page.
- **One primary action per screen**, visually distinct from everything else.
  Today several pages present six equal-weight buttons.
- **Counts on everything collapsible.** "Yogas (7)", "Notes (3)" — a closed
  section that does not say what is inside gets opened repeatedly or never.
- **No undifferentiated lists.** People, notes and the library get grouped
  headings rather than one long scroll.
- **Announce empty states with the action that fixes them**, never a bare
  "nothing here".
- **Keyboard: `/` focuses search, `Esc` clears selection**, everywhere,
  consistently.

---

### Explicitly not in this phase

Named so they do not creep in: encryption at rest, Swiss Ephemeris licensing,
the worker and Resend, branded reports, share links, muhūrta, the prediction
ledger, the public API, varṣaphala, and the iOS app. §16.3 is the largest risk
here; if it slips, §16.1 and §16.2 still ship a better product on their own.

### Order of work

`16.1 → 16.4 → 16.3 → 16.2 → 16.5 → 16.6 → 16.7`

16.1, 16.4 and 16.3 are done. The remaining order is **16.2 → 16.5 → 16.6 →
16.7**; 16.5 is nearly free and removes a whole class of "where is that".

16.1 unblocks everything else and is the biggest single improvement. 16.5 is
nearly free and removes a whole class of "where is that" friction. 16.3 is
last of the features because it is the only one that can genuinely overrun.
16.7 is applied continuously and swept at the end.

## Phase 8 — Beyond (ongoing)

Ranked by expected return:

1. **Mobile**: PWA with offline charts first (the WASM ephemeris makes this genuinely possible);
   Capacitor wrap for the app stores once retention is proven.
2. **Import from competitors** — Solar Fire, JHora, AstroSage, Parashara's Light. Every import
   format you support is a professional who can switch in an afternoon.
3. **The interpretation layer** — the grounded AI assistant, plus the forkable text library.
4. ~~**Rectification workspace**~~ — promoted to Phase 9 and started; see above.
5. **Western tropical as a first-class second tradition** — Placidus, progressions, solar arc,
   returns, Hellenistic (zodiacal releasing, annual profections). Doubles the market.
6. **The API product** — the calculation core is already a clean library; expose it. Competing
   Vedic APIs charge ~$29–89/month.
7. **Remaining daśā systems and Jaimini depth** — Kālachakra, Nārāyaṇa, Śūla; this is the
   "nine+ dasha systems" parity claim.
8. **Teams/institutes** — student seats, teacher review of student readings, assignment charts.
9. **Fixed stars, harmonics, midpoints, research database** (an astro-databank of public charts).

---

## The fast path: something she uses in two weeks

If you want a win before the long build, cut this line through the phases:

- **Days 1–2:** Phase 0.
- **Days 3–7:** Phase 1 sub-steps 1–5 only (ephemeris, sidereal, points _with nodes_, whole-sign
  houses, D9). That's already more than v0 has.
- **Days 8–12:** Phase 2 in full, deployed. She can add people.
- **Days 13–14:** Port the v0 "Now" + "Transits" screens onto the new data (a subset of Phase 3).

Two weeks in: a real URL, her account, unlimited people, correct charts with Rāhu/Ketu, live
transits. Then continue with Phase 1 in depth underneath her, without breaking anything —
which is exactly what the pure-core architecture buys you.
